"""
Main entry point for the LEM API.
"""

from lem_package.api import app

# This file is used as the entry point for the FastAPI application
# when running in a Docker container. 